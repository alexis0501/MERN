
const Product = require("../models/products.models")

//*CREATE
module.exports.createNewProduct = (req, res) => {
    Product.create(req.body)
        .then(newlyCreatedProduct => res.json({ product: newlyCreatedProduct }))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
}

//*FIND ALL
module.exports.findAllProduct = (req, res) => {
    Product.find()
        .then(allDaProducts => res.json( allDaProducts ))
        
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
}

//*FIND ONE
module.exports.findOneSingleProduct = (req, res) => {
    Product.findOne({ _id: req.params.id })
        .then(oneSingleProduct => res.json(oneSingleProduct))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
}