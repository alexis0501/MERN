import React from 'react'
import { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom'

const FormProducts = () => {
    const [products, setProducts] = useState([]) 
    const [title ,setTitle] = useState("");  
    const [price ,setPrice] = useState(0);
    const [description ,setDescription] = useState("");  

    useEffect( ()=>{
        axios.get("http://localhost:8000/api/products")
        .then(res => {
        console.log(res.data);
        setProducts(res.data)
        })
        .catch(err =>{
        console.log("ERROR",err);
        })
    },[])

    const createProduct = (e) =>{
        e.preventDefault()
        console.log("submitted");
        const newProduct = {
            title, 
            price, 
            description
        }
        console.log(newProduct);

        axios.post("http://localhost:8000/api/products", newProduct) 

        .then(res =>{
            console.log(res.data);
        })
        .catch(err =>{
            console.log(err);
        })
    }
return (

    <div className="App">
        <h1>Product Manager</h1>
        <form onSubmit={createProduct } >
            Title: <input onChange={(e) => setTitle(e.target.value)} value={title} />
            Price: <input onChange={(e) => setPrice(e.target.value)} type="number" value={price} />
            Description: <input onChange={(e) => setDescription(e.target.value)} value={description} />
            <button>Create</button>
        </form>
        <hr/>
        <h1>All Products</h1>
        {
            products.map((product)=>{
                return <h3 key={product._id}>
                <Link to={"/products/" + product._id}>{product.title}</Link>
                </h3> 
            })
        }
    </div>
)}

export default FormProducts