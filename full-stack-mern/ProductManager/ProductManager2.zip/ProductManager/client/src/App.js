import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import FormProducts from './components/FormProducts';
import SingleProduct from './components/SingleProduct';


function App() {
  return (
    <BrowserRouter>
    <div>
    </div>
        <Routes>
            <Route path='/' element={<FormProducts/>} />           
            <Route path='/products/:id' element={<SingleProduct/>} />
        </Routes>
    </BrowserRouter>
  )
}
export default App;